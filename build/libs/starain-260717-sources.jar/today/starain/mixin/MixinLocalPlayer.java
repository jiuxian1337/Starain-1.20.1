package today.starain.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import today.starain.Starain;
import today.starain.event.api.EventType;
import today.starain.event.impl.MotionEvent;
import today.starain.event.impl.PlayerTickEvent;
import today.starain.event.impl.RespawnEvent;
import today.starain.event.impl.SlowdownEvent;

@Mixin({class_746.class})
public abstract class MixinLocalPlayer extends class_742 {
    @Shadow
    private boolean wasSprinting;
    @Shadow
    @Final
    public class_634 connection;
    @Shadow
    private boolean wasShiftKeyDown;
    @Shadow
    private double xLast;
    @Shadow
    private double yLast1;
    @Shadow
    private double zLast;
    @Shadow
    private float yRotLast;
    @Shadow
    private float xRotLast;
    @Shadow
    private int positionReminder;
    @Shadow
    private boolean lastOnGround;
    @Shadow
    private boolean autoJumpEnabled;
    @Shadow
    @Final
    protected class_310 minecraft;

    @Shadow
    protected abstract boolean isControlledCamera();

    @Shadow
    protected abstract void sendIsSprintingIfNeeded();

    public MixinLocalPlayer(class_638 pClientLevel, GameProfile pGameProfile) {
        super(pClientLevel, pGameProfile);
    }

    @Inject(
            method = {"tick"},
            at = {@At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/player/AbstractClientPlayer;tick()V",
                    shift = At.Shift.BEFORE
            )}
    )
    public void injectUpdateEvent(CallbackInfo ci) {
        PlayerTickEvent event = new PlayerTickEvent();
        Starain.getInstance().getEventManager().call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    /**
     * @author PolarUser
     * @reason 傻逼Naven这么写
     */
    @Overwrite
    private void sendPosition() {
        MotionEvent eventPre = new MotionEvent(EventType.PRE, this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), this.method_36455(), this.method_24828());
        Starain.getInstance().getEventManager().call(eventPre);
        if (this.field_6012 <= 1) {
            Starain.getInstance().getEventManager().call(new RespawnEvent());
        }
        if (eventPre.isCancelled()) {
            Starain.getInstance().getEventManager().call(new MotionEvent(EventType.POST, eventPre.getYaw(), eventPre.getPitch()));
        } else {
            this.sendIsSprintingIfNeeded();
            boolean flag3 = this.method_5715();
            if (flag3 != this.wasShiftKeyDown) {
                class_2848.class_2849 serverboundplayercommandpacket$action1 = flag3 ? class_2848.class_2849.field_12979 : class_2848.class_2849.field_12984;
                this.connection.method_2883(new class_2848(this, serverboundplayercommandpacket$action1));
                this.wasShiftKeyDown = flag3;
            }

            if (this.isControlledCamera()) {
                double d4 = eventPre.getX() - this.xLast;
                double d0 = eventPre.getY() - this.yLast1;
                double d1 = eventPre.getZ() - this.zLast;
                double d2 = eventPre.getYaw() - this.yRotLast;
                double d3 = (double) (eventPre.getPitch() - this.xRotLast);
                this.positionReminder++;
                boolean flag1 = class_3532.method_41190(d4, d0, d1) > class_3532.method_33723(2.0E-4) || this.positionReminder >= 20;
                boolean flag2 = d2 != 0.0 || d3 != 0.0;
                if (this.method_5765()) {
                    class_243 vec3 = this.method_18798();
                    this.connection.method_2883(new class_2828.class_2830(vec3.field_1352, -999.0, vec3.field_1350, eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                    flag1 = false;
                } else if (flag1 && flag2) {
                    this.connection
                            .method_2883(new class_2828.class_2830(eventPre.getX(), eventPre.getY(), eventPre.getZ(), eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                } else if (flag1) {
                    this.connection.method_2883(new class_2828.class_2829(eventPre.getX(), eventPre.getY(), eventPre.getZ(), eventPre.isOnGround()));
                } else if (flag2) {
                    this.connection.method_2883(new class_2828.class_2831(eventPre.getYaw(), eventPre.getPitch(), eventPre.isOnGround()));
                } else if (this.lastOnGround != eventPre.isOnGround()) {
                    this.connection.method_2883(new class_2828.class_5911(eventPre.isOnGround()));
                }

                if (flag1) {
                    this.xLast = eventPre.getX();
                    this.yLast1 = eventPre.getY();
                    this.zLast = eventPre.getZ();
                    this.positionReminder = 0;
                }

                if (flag2) {
                    this.yRotLast = eventPre.getYaw();
                    this.xRotLast = eventPre.getPitch();
                }

                this.lastOnGround = eventPre.isOnGround();
                this.autoJumpEnabled = (Boolean) this.minecraft.field_1690.method_42423().method_41753();
            }

            Starain.getInstance().getEventManager().call(new MotionEvent(EventType.POST, eventPre.getYaw(), eventPre.getPitch()));
        }
    }

    @Redirect(
            method = {"aiStep"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/player/LocalPlayer;isUsingItem()Z",
                    ordinal = 0
            )
    )
    public boolean onSlowdown(class_746 localPlayer) {
        if (localPlayer.method_6115()) {
            SlowdownEvent event = new SlowdownEvent();
            Starain.getInstance().getEventManager().call(event);
            return !event.isCancelled();
        }
        return false;
    }
}
