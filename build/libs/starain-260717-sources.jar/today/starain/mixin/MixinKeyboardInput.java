package today.starain.mixin;


import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import today.starain.Starain;
import today.starain.event.impl.MoveInputEvent;

@Mixin({class_743.class})
public class MixinKeyboardInput extends class_744 {
    @Inject(
            at = {@At("TAIL")},
            method = {"tick"}
    )
    private void onTickTail(boolean pIsMovingSlowly, float p_234119_, CallbackInfo ci) {
        this.field_3905 = this.field_3910 == this.field_3909 ? 0.0F : (this.field_3910 ? 1.0F : -1.0F);
        this.field_3907 = this.field_3908 == this.field_3906 ? 0.0F : (this.field_3908 ? 1.0F : -1.0F);
        MoveInputEvent eventMoveInput = new MoveInputEvent(this.field_3905, this.field_3907, this.field_3904, this.field_3903, 0.3);
        Starain.getInstance().getEventManager().call(eventMoveInput);
        double sneakMultiplier = eventMoveInput.getSneakSlowDownMultiplier();
        this.field_3905 = eventMoveInput.getForward();
        this.field_3907 = eventMoveInput.getStrafe();
        this.field_3904 = eventMoveInput.isJump();
        this.field_3903 = eventMoveInput.isSneak();
        if (pIsMovingSlowly) {
            this.field_3907 = (float)((double)this.field_3907 * sneakMultiplier);
            this.field_3905 = (float)((double)this.field_3905 * sneakMultiplier);
        }
    }
}
