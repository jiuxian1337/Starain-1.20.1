package today.starain.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_1792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import today.starain.Starain;
import today.starain.event.impl.UseItemRayTraceEvent;

@Mixin({class_1792.class})
public class MixinItem {
    @Redirect(
            method = {"getPlayerPOVHitResult"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;getYRot()F"
            )
    )
    private static float hookRayTraceYRot(class_1657 instance) {
        UseItemRayTraceEvent event = new UseItemRayTraceEvent(instance.method_36454(), instance.method_36455());
        Starain.getInstance().getEventManager().call(event);
        return event.getYaw();
    }

    @Redirect(
            method = {"getPlayerPOVHitResult"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;getXRot()F"
            )
    )
    private static float hookRayTraceXRot(class_1657 instance) {
        UseItemRayTraceEvent event = new UseItemRayTraceEvent(instance.method_36454(), instance.method_36455());
        Starain.getInstance().getEventManager().call(event);
        return event.getPitch();
    }
}
