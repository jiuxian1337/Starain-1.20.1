package today.starain.mixin;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import today.starain.Starain;
import today.starain.event.impl.AttackSlowdownEvent;
import today.starain.event.impl.AttackYawEvent;

@Mixin({class_1657.class})
public abstract class MixinPlayer extends class_1309 {
    protected MixinPlayer(class_1299<? extends class_1309> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Redirect(
            method = {"attack"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;getYRot()F"
            )
    )
    private float hookFixRotation(class_1657 instance) {
        AttackYawEvent event = new AttackYawEvent(instance.method_36454());
        Starain.getInstance().getEventManager().call(event);
        return event.getYaw();
    }

    @Redirect(
            method = {"attack"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;setDeltaMovement(Lnet/minecraft/world/phys/Vec3;)V"
            )
    )
    private void hookSetDeltaMovement(class_1657 instance, class_243 vec3) {
        AttackSlowdownEvent event = new AttackSlowdownEvent();
        Starain.getInstance().getEventManager().call(event);
        if (!event.isCancelled()) {
            instance.method_18799(vec3);
        }
    }

    @Redirect(
            method = {"attack"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;setSprinting(Z)V"
            )
    )
    private void hookSetSprinting(class_1657 instance, boolean sprinting) {
        AttackSlowdownEvent event = new AttackSlowdownEvent();
        Starain.getInstance().getEventManager().call(event);
        if (!event.isCancelled()) {
            instance.method_5728(sprinting);
        }
    }

//    @Inject(
//            method = {"isStayingOnGroundSurface"},
//            at = {@At("RETURN")},
//            cancellable = true
//    )
//    private void isStayingOnGroundSurface(CallbackInfoReturnable<Boolean> info) {
//        EventStayingOnGroundSurface event = new EventStayingOnGroundSurface((Boolean)info.getReturnValue());
//        Naven.getInstance().getEventManager().call(event);
//        info.setReturnValue(event.isStay());
//    }
}
