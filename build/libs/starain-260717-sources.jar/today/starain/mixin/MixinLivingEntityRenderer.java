package today.starain.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import today.starain.Starain;
import today.starain.event.impl.RotationAnimationEvent;

@Mixin({class_922.class})
public class MixinLivingEntityRenderer<T extends class_1309, M extends class_583<T>> {
    @Inject(
            method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
            at = {@At("HEAD")}
    )
    private void renderHead(
            T pEntity, float pEntityYaw, float pPartialTicks, class_4587 pMatrixStack, class_4597 pBuffer, int pPackedLight, CallbackInfo ci
    ) {
        RotationAnimationEvent.currentEntity = pEntity;
    }

    @Redirect(
            method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/Mth;rotLerp(FFF)F",
                    ordinal = 1
            )
    )
    private float rotAnimationYaw(float pDelta, float pStart, float pEnd) {
        RotationAnimationEvent event = new RotationAnimationEvent(pEnd, pStart, 0.0F, 0.0F);
        if (RotationAnimationEvent.currentEntity == class_310.method_1551().field_1724) {
            Starain.getInstance().getEventManager().call(event);
        }

        return class_3532.method_17821(pDelta, event.getLastYaw(), event.getYaw());
    }

    @Redirect(
            method = {"render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/Mth;lerp(FFF)F",
                    ordinal = 0
            )
    )
    private float rotAnimationPitch(float pDelta, float pStart, float pEnd) {
        RotationAnimationEvent event = new RotationAnimationEvent(0.0F, 0.0F, pEnd, pStart);
        if (RotationAnimationEvent.currentEntity == class_310.method_1551().field_1724) {
            Starain.getInstance().getEventManager().call(event);
        }

        return class_3532.method_16439(pDelta, event.getLastPitch(), event.getPitch());
    }
}
