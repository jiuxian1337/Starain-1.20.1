package today.starain.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import today.starain.Starain;
import today.starain.event.impl.FallFlyingEvent;
import today.starain.event.impl.JumpEvent;
import today.starain.event.impl.RotationAnimationEvent;

@Mixin({class_1309.class})
public abstract class MixinLivingEntity extends class_1297 {
    public MixinLivingEntity(class_1299<?> pEntityType, class_1937 pLevel) {
        super(pEntityType, pLevel);
    }

    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F",
                    opcode = 182,
                    ordinal = 0
            ),
            method = {"jumpFromGround"}
    )
    private float modifyJumpYaw(class_1309 entity) {
        JumpEvent event = new JumpEvent(entity.method_36454());
        Starain.getInstance().getEventManager().call(event);
        return event.getYaw();
    }

    @Redirect(
            method = {"travel"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/LivingEntity;getXRot()F"
            )
    )
    private float hookModifyFallFlyingPitch(class_1309 instance) {
        FallFlyingEvent event = new FallFlyingEvent(instance.method_36455());
        Starain.getInstance().getEventManager().call(event);
        return event.getPitch();
    }

//    @Inject(
//            method = {"hasEffect"},
//            at = {@At("HEAD")},
//            cancellable = true
//    )
//    private void hasEffect(MobEffect pEffect, CallbackInfoReturnable<Boolean> cir) {
//        LivingEntity thisEntity = (LivingEntity)(Object)this;
//        if (thisEntity == Minecraft.getInstance().player) {
//            FullBright fullBright = (FullBright)Naven.getInstance().getModuleManager().getModule(FullBright.class);
//            if (pEffect == MobEffects.NIGHT_VISION && fullBright.isEnabled()) {
//                cir.setReturnValue(true);
//                cir.cancel();
//            }
//
//            AntiNausea antiNausea = (AntiNausea)Naven.getInstance().getModuleManager().getModule(AntiNausea.class);
//            if (pEffect == MobEffects.CONFUSION && antiNausea.isEnabled()) {
//                cir.setReturnValue(false);
//                cir.cancel();
//            }
//        }
//    }

    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/LivingEntity;getYRot()F"
            ),
            method = {"tickHeadTurn"}
    )
    private float modifyHeadYaw(class_1309 entity) {
        if (entity == class_310.method_1551().field_1724) {
            RotationAnimationEvent event = new RotationAnimationEvent(entity.method_36454(), 0.0F, 0.0F, 0.0F);
            Starain.getInstance().getEventManager().call(event);
            return event.getYaw();
        } else {
            return entity.method_36454();
        }
    }
}
