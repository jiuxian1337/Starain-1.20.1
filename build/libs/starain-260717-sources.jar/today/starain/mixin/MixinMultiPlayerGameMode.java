package today.starain.mixin;

import net.minecraft.class_2596;
import net.minecraft.class_634;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import today.starain.Starain;
import today.starain.event.impl.PositionItemEvent;

@Mixin({class_636.class})
public class MixinMultiPlayerGameMode {
    @Redirect(
            method = {"useItem"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/multiplayer/ClientPacketListener;send(Lnet/minecraft/network/protocol/Packet;)V",
                    ordinal = 0
            )
    )
    public void onSendPacket(class_634 instance, class_2596<?> pPacket) {
        PositionItemEvent event = new PositionItemEvent(pPacket);
        Starain.getInstance().getEventManager().call(event);
        if (!event.isCancelled()) {
            instance.method_2883(event.getPacket());
        }
    }

//    @Inject(
//            method = {"startDestroyBlock"},
//            at = {@At("HEAD")}
//    )
//    public void onStartDestroyBlock(BlockPos pLoc, Direction pFace, CallbackInfoReturnable<Boolean> cir) {
//        Naven.getInstance().getEventManager().call(new EventDestroyBlock(pLoc, pFace));
//    }
}
