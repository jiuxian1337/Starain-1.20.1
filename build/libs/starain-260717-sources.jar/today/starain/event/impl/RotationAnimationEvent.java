package today.starain.event.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_1297;
import today.starain.event.api.Event;

@Getter
@Setter
@AllArgsConstructor
public class RotationAnimationEvent implements Event {
    public static class_1297 currentEntity;
    private float yaw;
    private float lastYaw;
    private float pitch;
    private float lastPitch;
}
