package today.starain.event.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_2596;
import today.starain.event.api.Cancellable;
import today.starain.event.api.Event;

@Getter
@Setter
public class PositionItemEvent implements Event, Cancellable {
    private boolean cancelled;
    private class_2596<?> packet;

    public PositionItemEvent(class_2596<?> packet) {
        this.packet = packet;
    }
}
