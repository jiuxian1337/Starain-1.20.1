package today.starain.event.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_332;
import today.starain.event.api.Event;

@Getter
@Setter
@AllArgsConstructor
public class RenderSkiaEvent implements Event {
    private class_332 guiGraphics;
    private float partialTick;
}
