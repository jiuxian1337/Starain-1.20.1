package today.starain.event.impl;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.class_1297;
import today.starain.event.api.Event;

@Getter
@Setter
@AllArgsConstructor
public class RayTraceEvent implements Event {
    public class_1297 entity;
    public float yaw;
    public float pitch;
}
