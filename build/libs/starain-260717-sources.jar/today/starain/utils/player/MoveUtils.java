package today.starain.utils.player;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import today.starain.event.impl.MoveInputEvent;

public class MoveUtils {
    private static final class_310 mc = class_310.method_1551();

    public static boolean isMoving() {
        if (mc.field_1724 == null) return false;
        return mc.field_1724.field_3913.field_3905 != 0.0F || mc.field_1724.field_3913.field_3907 != 0.0F;
    }

    public static double getSpeed() {
        if (mc.field_1724 == null) return 0.0;
        return Math.sqrt(
                mc.field_1724.method_18798().field_1352 * mc.field_1724.method_18798().field_1352 +
                        mc.field_1724.method_18798().field_1350 * mc.field_1724.method_18798().field_1350
        );
    }

    public static void setSpeed(double speed) {
        if (mc.field_1724 == null) return;

        class_243 motion = mc.field_1724.method_18798();
        float yaw = mc.field_1724.method_36454();

        double forward = mc.field_1724.field_3913.field_3905;
        double strafe = mc.field_1724.field_3913.field_3907;

        if (forward != 0.0 || strafe != 0.0) {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float) (forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float) (forward > 0.0 ? 45 : -45);
                }

                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }

            double cos = Math.cos(Math.toRadians(yaw + 90.0F));
            double sin = Math.sin(Math.toRadians(yaw + 90.0F));

            mc.field_1724.method_18800(
                    forward * speed * cos + strafe * speed * sin,
                    motion.field_1351,
                    forward * speed * sin - strafe * speed * cos
            );
        } else {
            mc.field_1724.method_18800(0, motion.field_1351, 0);
        }
    }

    public static double getDirection() {
        if (mc.field_1724 == null) return 0.0;

        float yaw = mc.field_1724.method_36454();
        float forward = mc.field_1724.field_3913.field_3905;
        float strafe = mc.field_1724.field_3913.field_3907;

        if (forward < 0.0f) {
            yaw += 180.0f;
        }

        float strafeAngle = 0.0f;
        if (strafe < 0.0f) {
            strafeAngle = -90.0f;
        } else if (strafe > 0.0f) {
            strafeAngle = 90.0f;
        }

        if (forward != 0.0f) {
            if (strafe >= 0.0f) {
                yaw += strafeAngle * (forward > 0.0f ? 0.5f : -0.5f);
            } else {
                yaw -= strafeAngle * (forward > 0.0f ? 0.5f : -0.5f);
            }
        }

        return Math.toRadians(yaw);
    }


    public static void fixMovement(MoveInputEvent event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();
        int angleUnit = 45;
        float angleTolerance = 22.5F;
        float directionFactor = Math.max(Math.abs(forward), Math.abs(strafe));
        double angleDifference = class_3532.method_15393(direction(forward, strafe) - yaw);
        double angleDistance = Math.abs(angleDifference);
        forward = 0.0F;
        strafe = 0.0F;
        if (angleDistance <= (double) ((float) angleUnit + angleTolerance)) {
            forward++;
        } else if (angleDistance >= (double) (180.0F - (float) angleUnit - angleTolerance)) {
            forward--;
        }

        if (angleDifference >= (double) ((float) angleUnit - angleTolerance) && angleDifference <= (double) (180.0F - (float) angleUnit + angleTolerance)) {
            strafe--;
        } else if (angleDifference <= (double) ((float) (-angleUnit) + angleTolerance) && angleDifference >= (double) (-180.0F + (float) angleUnit - angleTolerance)) {
            strafe++;
        }

        forward *= directionFactor;
        strafe *= directionFactor;
        event.setForward(forward);
        event.setStrafe(strafe);
    }

    private static float direction(float forward, float strafe) {
        float direction = mc.field_1724.method_36454();
        boolean isMovingForward = forward > 0.0F;
        boolean isMovingBack = forward < 0.0F;
        boolean isMovingRight = strafe > 0.0F;
        boolean isMovingLeft = strafe < 0.0F;
        boolean isMovingSideways = isMovingRight || isMovingLeft;
        boolean isMovingStraight = isMovingForward || isMovingBack;
        if (forward != 0.0F || strafe != 0.0F) {
            if (isMovingBack && !isMovingSideways) {
                return direction + 180.0F;
            }

            if (isMovingForward && isMovingLeft) {
                return direction + 45.0F;
            }

            if (isMovingForward && isMovingRight) {
                return direction - 45.0F;
            }

            if (!isMovingStraight && isMovingLeft) {
                return direction + 90.0F;
            }

            if (!isMovingStraight && isMovingRight) {
                return direction - 90.0F;
            }

            if (isMovingBack && isMovingLeft) {
                return direction + 135.0F;
            }

            if (isMovingBack) {
                return direction - 135.0F;
            }
        }

        return direction;
    }
}