package today.starain.utils.player;

import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class FallingPlayer {
    private static final class_310 mc = class_310.method_1551();

    public double x, y, z;
    public double motionX, motionY, motionZ;
    public float yaw;

    public FallingPlayer(class_1657 player) {
        this.x = player.method_23317();
        this.y = player.method_23318();
        this.z = player.method_23321();
        this.motionX = player.method_18798().field_1352;
        this.motionY = player.method_18798().field_1351;
        this.motionZ = player.method_18798().field_1350;
        this.yaw = player.method_36454();
    }

    public FallingPlayer(double x, double y, double z, double motionX, double motionY, double motionZ, float yaw) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.motionX = motionX;
        this.motionY = motionY;
        this.motionZ = motionZ;
        this.yaw = yaw;
    }

    public void calculate(int ticks) {
        for (int i = 0; i < ticks; i++) {
            update();
        }
    }

    public void update() {
        motionY -= 0.08;
        motionY *= 0.98;
        motionX *= 0.91;
        motionZ *= 0.91;

        x += motionX;
        y += motionY;
        z += motionZ;
    }

    public class_243 getPosition() {
        return new class_243(x, y, z);
    }

    public double getDistanceTo(double x, double y, double z) {
        double dx = this.x - x;
        double dy = this.y - y;
        double dz = this.z - z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public boolean isCollidedHorizontally() {
        if (mc.field_1687 == null) return false;

        // 简单的碰撞检测
        return mc.field_1687.method_8320(net.minecraft.class_2338.method_49637(x, y, z)).method_51366();
    }

    public boolean isCollidedVertically() {
        if (mc.field_1687 == null) return false;

        return mc.field_1687.method_8320(net.minecraft.class_2338.method_49637(x, y - 0.1, z)).method_51366();
    }
}