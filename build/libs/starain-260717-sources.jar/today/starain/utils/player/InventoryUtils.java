package today.starain.utils.player;

import net.minecraft.class_1304;
import net.minecraft.class_1310;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1741;
import net.minecraft.class_1743;
import net.minecraft.class_1744;
import net.minecraft.class_1747;
import net.minecraft.class_1751;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1779;
import net.minecraft.class_1781;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1798;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1809;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2302;
import net.minecraft.class_2356;
import net.minecraft.class_2482;
import net.minecraft.class_2484;
import net.minecraft.class_310;
import net.minecraft.class_4771;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class InventoryUtils {
    public static final List<class_2248> blacklistedBlocks = Arrays.asList(
            class_2246.field_10124,
            class_2246.field_10382,
            class_2246.field_10164,
            class_2246.field_10485,
            class_2246.field_10285,
            class_2246.field_10285,
            class_2246.field_10576,
            class_2246.field_10477,
            class_2246.field_10418,
            class_2246.field_10442,
            class_2246.field_10013,
            class_2246.field_10034,
            class_2246.field_10380,
            class_2246.field_10336,
            class_2246.field_10535,
            class_2246.field_10380,
            class_2246.field_10179,
            class_2246.field_10223,
            class_2246.field_10375,
            class_2246.field_10571,
            class_2246.field_10212,
            class_2246.field_10090,
            class_2246.field_10158,
            class_2246.field_10224,
            class_2246.field_10582,
            class_2246.field_10494,
            class_2246.field_10363,
            class_2246.field_10214,
            class_2246.field_10589,
            class_2246.field_10348,
            class_2246.field_10167,
            class_2246.field_9995,
            class_2246.field_10559,
            class_2246.field_10251,
            class_2246.field_10597,
            class_2246.field_10583,
            class_2246.field_9983,
            class_2246.field_10181,
            class_2246.field_10102,
            class_2246.field_10029,
            class_2246.field_10200,
            class_2246.field_10228,
            class_2246.field_9980,
            class_2246.field_10343,
            class_2246.field_10261,
            class_2246.field_10625,
            class_2246.field_10620,
            class_2246.field_10523,
            class_2246.field_10495
    );
    private static final class_310 mc = class_310.method_1551();

    public static boolean shouldDisableFeatures() {
        return getAllItems().stream().anyMatch(item -> {
            if (item.method_7960()) {
                return false;
            } else {
                String string = item.method_7954().getString();
                return string.contains("长按点击") || string.contains("点击使用") || string.contains("离开游戏") || string.contains("选择一个队伍") || string.contains("再来一局");
            }
        });
    }

    public static boolean isGoldenHead(class_1799 e) {
        if (e.method_7960()) {
            return false;
        } else {
            if (e.method_7909() instanceof class_1747 item) {
                return item.method_7711() instanceof class_2484;
            }

            return false;
        }
    }

    public static boolean isSharpnessAxe(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        } else if (!(stack.method_7909() instanceof class_1743)) {
            return false;
        } else {
            int itemEnchantmentLevel = class_1890.method_8225(class_1893.field_9118, stack);
            return itemEnchantmentLevel >= 8 && itemEnchantmentLevel < 50;
        }
    }

    public static boolean isGodAxe(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        } else {
            return stack.method_7909() == class_1802.field_8825 && class_1890.method_8225(class_1893.field_9118, stack) > 100;
        }
    }

    public static boolean isEnchantedGApple(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() == class_1802.field_8367;
    }

    public static boolean isEndCrystal(class_1799 stack) {
        return !stack.method_7960() && stack.method_7909() == class_1802.field_8301;
    }

    public static boolean isKBBall(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        } else {
            return stack.method_7909() == class_1802.field_8777 && class_1890.method_8225(class_1893.field_9121, stack) > 1;
        }
    }

    public static boolean isKBStick(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        } else {
            return stack.method_7909() == class_1802.field_8600 && class_1890.method_8225(class_1893.field_9121, stack) > 1;
        }
    }

    public static int findEmptyInventory() {
        for (int i = 9; i < mc.field_1724.method_31548().field_7547.size(); i++) {
            if (mc.field_1724.method_31548().field_7547.get(i).method_7960()) {
                return i;
            }
        }

        return -1;
    }

    public static int findEmptySlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().field_7547.get(i).method_7960()) {
                return i;
            }
        }

        return -1;
    }

    public static Integer findItemHotbar(class_1792 item) {
        for (int i = 0; i < 9; i++) {
            class_1799 itemStack = mc.field_1724.method_31548().field_7547.get(i);
            if (itemStack.method_7909() == item) {
                return i;
            }
        }

        return null;
    }

    public static int getPunchLevel(class_1799 stack) {
        return class_1890.method_8225(class_1893.field_9116, stack);
    }

    public static int getPowerLevel(class_1799 stack) {
        return class_1890.method_8225(class_1893.field_9103, stack);
    }

    public static List<class_1799> getAllItems() {
        ArrayList<class_1799> list = new ArrayList<>(40);
        list.addAll(mc.field_1724.method_31548().field_7547);
        list.addAll(mc.field_1724.method_31548().field_7548);
        return list;
    }

    public static float getBestArmorScore(class_1304 slot) {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1738 && ((class_1738) item.method_7909()).method_7685() == slot)
                .map(InventoryUtils::getProtection)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static float getCurrentArmorScore(class_1304 slot) {
        if (slot == class_1304.field_6169) {
            return getProtection(mc.field_1724.method_31548().field_7548.get(3));
        } else if (slot == class_1304.field_6174) {
            return getProtection(mc.field_1724.method_31548().field_7548.get(2));
        } else if (slot == class_1304.field_6172) {
            return getProtection(mc.field_1724.method_31548().field_7548.get(1));
        } else {
            return slot == class_1304.field_6166 ? getProtection(mc.field_1724.method_31548().field_7548.get(0)) : 0.0F;
        }
    }

    public static float getBestSwordDamage() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1829)
                .map(InventoryUtils::getSwordDamage)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestSword() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1829)
                .max(Comparator.comparingInt(s -> (int) (getSwordDamage(s) * 100.0F)))
                .orElse(null);
    }

    public static int getItemStackSlot(class_1799 stack) {
        if (stack == null) {
            return -1;
        } else {
            for (int i = 0; i < mc.field_1724.method_31548().field_7547.size(); i++) {
                if (mc.field_1724.method_31548().field_7547.get(i) == stack) {
                    return i;
                }
            }

            return -1;
        }
    }

    public static boolean isItemValid(class_1799 s) {
        if (!s.method_7960()) {
            if (s.method_7909() instanceof class_1809) {
                return false;
            }

            String string = s.method_7954().getString();
            if (string.contains("Click")) {
                return false;
            }

            if (string.contains("Right")) {
                return false;
            }

            if (string.contains("点击")) {
                return false;
            }

            if (string.contains("Teleport")) {
                return false;
            }

            if (string.contains("使用")) {
                return false;
            }

            if (string.contains("传送")) {
                return false;
            }

            return !string.contains("再来");
        }

        return true;
    }

    public static int getItemSlot(class_1792 item) {
        for (int i = 0; i < mc.field_1724.method_31548().field_7547.size(); i++) {
            class_1799 itemStack = mc.field_1724.method_31548().field_7547.get(i);
            if (itemStack.method_7909() == item) {
                return i;
            }
        }

        return -1;
    }

    public static class_1799 getBestProjectile() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && (item.method_7909() == class_1802.field_8803 || item.method_7909() == class_1802.field_8543) && isItemValid(item))
                .max(Comparator.comparingInt(class_1799::method_7947))
                .orElse(null);
    }

    public static class_1799 getFishingRod() {
        return getAllItems().stream().filter(item -> !item.method_7960() && item.method_7909() instanceof class_1787 && isItemValid(item)).findAny().orElse(null);
    }

    public static int getBlockCountInInventory() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1747 && isValidStack(item) && isItemValid(item))
                .mapToInt(class_1799::method_7947)
                .sum();
    }

    public static class_1799 getWorstProjectile() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && (item.method_7909() == class_1802.field_8803 || item.method_7909() == class_1802.field_8543))
                .min(Comparator.comparingInt(class_1799::method_7947))
                .orElse(null);
    }

    public static class_1799 getWorstArrow() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1744 && isItemValid(item))
                .min(Comparator.comparingInt(class_1799::method_7947))
                .orElse(null);
    }

    public static class_1799 getWorstBlock() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1747 && isValidStack(item) && isItemValid(item))
                .min(Comparator.comparingInt(class_1799::method_7947))
                .orElse(null);
    }

    public static class_1799 getBestBlock() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1747 && isValidStack(item) && isItemValid(item))
                .max(Comparator.comparingInt(class_1799::method_7947))
                .orElse(null);
    }

    public static float getBestPickaxeScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1810 && isItemValid(item))
                .map(InventoryUtils::getToolScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestPickaxe() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1810 && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getToolScore(s) * 100.0F)))
                .orElse(null);
    }

    public static float getBestAxeScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1743 && !isSharpnessAxe(item) && isItemValid(item))
                .map(InventoryUtils::getToolScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestAxe() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1743 && !isSharpnessAxe(item) && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getToolScore(s) * 100.0F)))
                .orElse(null);
    }

    public static class_1799 getBestShapeAxe() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1743 && isSharpnessAxe(item) && isItemValid(item) && !isGodAxe(item))
                .max(Comparator.comparingInt(s -> (int) (getAxeDamage(s) * 100.0F)))
                .orElse(null);
    }

    public static float getBestShovelScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1821 && isItemValid(item))
                .map(InventoryUtils::getToolScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestShovel() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1821 && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getToolScore(s) * 100.0F)))
                .orElse(null);
    }

    public static float getBestCrossbowScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1764 && isItemValid(item))
                .map(InventoryUtils::getCrossbowScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestCrossbow() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1764 && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getCrossbowScore(s) * 100.0F)))
                .orElse(null);
    }

    public static float getBestPunchBowScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1753 && isItemValid(item))
                .map(InventoryUtils::getPunchBowScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestPunchBow() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1753 && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getPunchBowScore(s) * 100.0F)))
                .orElse(null);
    }

    public static float getBestPowerBowScore() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1753 && isItemValid(item))
                .map(InventoryUtils::getPowerBowScore)
                .max(Float::compareTo)
                .orElse(0.0F);
    }

    public static class_1799 getBestPowerBow() {
        return getAllItems()
                .stream()
                .filter(item -> !item.method_7960() && item.method_7909() instanceof class_1753 && isItemValid(item))
                .max(Comparator.comparingInt(s -> (int) (getPowerBowScore(s) * 100.0F)))
                .orElse(null);
    }

    public static boolean isPunchBow(class_1799 stack) {
        return getPunchBowScore(stack) > 10.0F && isItemValid(stack);
    }

    public static boolean isPowerBow(class_1799 stack) {
        return getPowerBowScore(stack) > 10.0F && isItemValid(stack);
    }

    public static boolean hasItem(class_1792 checkItem) {
        return getAllItems().stream().anyMatch(item -> !item.method_7960() && item.method_7909() == checkItem);
    }

    public static int getItemCount(class_1792 checkItem) {
        return getAllItems().stream().filter(item -> !item.method_7960() && item.method_7909() == checkItem).mapToInt(class_1799::method_7947).sum();
    }

    public static float getPunchBowScore(class_1799 stack) {
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else if (stack.method_7909() instanceof class_1753) {
            float valence = 10.0F;
            valence += (float) class_1890.method_8225(class_1893.field_9116, stack);
            valence += (float) class_1890.method_8225(class_1893.field_9125, stack);
            valence += (float) class_1890.method_8225(class_1893.field_9126, stack);
            valence += (float) class_1890.method_8225(class_1893.field_9103, stack) / 10.0F;
            return valence + (float) stack.method_7919() / (float) stack.method_7936();
        } else {
            return 0.0F;
        }
    }

    public static float getPowerBowScore(class_1799 stack) {
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else if (stack.method_7909() instanceof class_1753) {
            float valence = 10.0F;
            valence += (float) class_1890.method_8225(class_1893.field_9116, stack) / 10.0F;
            valence += (float) class_1890.method_8225(class_1893.field_9125, stack);
            valence += (float) class_1890.method_8225(class_1893.field_9126, stack);
            valence += (float) class_1890.method_8225(class_1893.field_9103, stack);
            return valence + (float) stack.method_7919() / (float) stack.method_7936();
        } else {
            return 0.0F;
        }
    }

    public static float getToolScore(class_1799 stack) {
        float valence = 0.0F;
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else if (isGodItem(stack)) {
            return 0.0F;
        } else if (isSharpnessAxe(stack)) {
            return 0.0F;
        } else {
            if (stack.method_7909() instanceof class_1810) {
                valence += stack.method_7924(class_2246.field_10340.method_9564());
            } else if (stack.method_7909() instanceof class_1743) {
                valence += stack.method_7924(class_2246.field_10431.method_9564());
            } else {
                if (!(stack.method_7909() instanceof class_1821)) {
                    return 0.0F;
                }

                valence += stack.method_7924(class_2246.field_10566.method_9564());
            }

            int efficiency = class_1890.method_8225(class_1893.field_9131, stack);
            if (efficiency > 0) {
                valence += (float) efficiency * 0.0075F;
            }

            return valence;
        }
    }

    public static float getAxeDamage(class_1799 stack) {
        float valence = 0.0F;
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else {
            if (stack.method_7909() instanceof class_1743 axe && isSharpnessAxe(stack)) {
                if (axe == class_1802.field_8406) {
                    valence += 4.0F;
                } else if (axe == class_1802.field_8062) {
                    valence += 5.0F;
                } else if (axe == class_1802.field_8475) {
                    valence += 6.0F;
                } else if (axe == class_1802.field_8825) {
                    valence += 4.0F;
                } else if (axe == class_1802.field_8556) {
                    valence += 7.0F;
                }
            }

            int itemEnchantmentLevel = class_1890.method_8225(class_1893.field_9118, stack);
            if (itemEnchantmentLevel > 0) {
                float damageBonus = class_1893.field_9118.method_8196(itemEnchantmentLevel, class_1310.field_6290);
                valence += damageBonus;
            }

            return valence;
        }
    }

    public static float getSwordDamage(class_1799 stack) {
        float valence = 0.0F;
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else {
            if (stack.method_7909() instanceof class_1829 sword) {
                valence += sword.method_8020() + 1.0F;
            }

            int itemEnchantmentLevel = class_1890.method_8225(class_1893.field_9118, stack);
            if (itemEnchantmentLevel > 0) {
                float damageBonus = class_1893.field_9118.method_8196(itemEnchantmentLevel, class_1310.field_6290);
                valence += damageBonus;
            }

            return valence;
        }
    }

    public static float getProtection(class_1799 itemStack) {
        int valence = 0;
        if (itemStack == null) {
            return 0.0F;
        } else if (itemStack.method_7960()) {
            return 0.0F;
        } else {
            if (itemStack.method_7909() instanceof class_1738 armor) {
                class_1741 material = armor.method_7686();
                if (material == class_1740.field_7897) {
                    valence += 100;
                } else if (material == class_1740.field_7887) {
                    valence += 200;
                } else if (material == class_1740.field_7892) {
                    valence += 400;
                } else if (material == class_1740.field_7895) {
                    valence += 300;
                } else if (material == class_1740.field_7889) {
                    valence += 500;
                } else if (material == class_1740.field_21977) {
                    valence += 600;
                }
            }

            valence += class_1890.method_8225(class_1893.field_9111, itemStack);
            return (float) valence;
        }
    }

    public static float getCrossbowScore(class_1799 stack) {
        int valence = 0;
        if (stack == null) {
            return 0.0F;
        } else if (stack.method_7960()) {
            return 0.0F;
        } else {
            if (stack.method_7909() instanceof class_1764) {
                valence += class_1890.method_8225(class_1893.field_9098, stack);
                valence += class_1890.method_8225(class_1893.field_9108, stack);
                valence += class_1890.method_8225(class_1893.field_9132, stack);
            }

            return (float) valence;
        }
    }

    public static boolean isGodItem(class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        } else if (stack.method_7909() instanceof class_1743
                && stack.method_7909() == class_1802.field_8825
                && class_1890.method_8225(class_1893.field_9118, stack) > 100) {
            return true;
        } else if (stack.method_7909() == class_1802.field_8777 && class_1890.method_8225(class_1893.field_9121, stack) > 1) {
            return true;
        } else {
            return stack.method_7909() == class_1802.field_8288 || stack.method_7909() == class_1802.field_8301;
        }
    }

    public static boolean isCommonItemUseful(class_1799 stack) {
        if (stack.method_7960()) {
            return true;
        } else {
            class_1792 item = stack.method_7909();
            if (item instanceof class_1747 block) {
                if (block.method_7711() == class_2246.field_10485) {
                    return false;
                }

                return block.method_7711() != class_2246.field_10343;
            } else {
                if (item instanceof class_1751) {
                    return false;
                }

                if (item instanceof class_1779) {
                    return false;
                }

                if (item instanceof class_1781) {
                    return false;
                }

                if (item == class_1802.field_8317 || item == class_1802.field_8309 || item == class_1802.field_8188 || item == class_1802.field_8706) {
                    return false;
                }

                return item != class_1802.field_8884;
            }
        }
    }

    public static boolean isValidStack(class_1799 stack) {
        if (stack == null || !(stack.method_7909() instanceof class_1747) || stack.method_7947() <= 1) {
            return false;
        } else if (!InventoryUtils.isItemValid(stack)) {
            return false;
        } else {
            String string = stack.method_7954().getString();
            if (string.contains("Click") || string.contains("点击")) {
                return false;
            } else if (stack.method_7909() instanceof class_1798) {
                return false;
            } else {
                class_2248 block = ((class_1747) stack.method_7909()).method_7711();
                if (block instanceof class_2356) {
                    return false;
                } else if (block instanceof class_2261) {
                    return false;
                } else if (block instanceof class_4771) {
                    return false;
                } else if (block instanceof class_2302) {
                    return false;
                } else {
                    return !(block instanceof class_2482) && !blacklistedBlocks.contains(block);
                }
            }
        }
    }
}
