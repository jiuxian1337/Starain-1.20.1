package today.starain.utils.client;

import net.minecraft.class_2561;
import net.minecraft.class_338;
import today.starain.Starain;
import today.starain.utils.wrapper.Wrapper;

public class ChatUtils implements Wrapper {
    private static final String PREFIX = "§7[§b" + Starain.NAME + "§7] ";

    public static void component(class_2561 component) {
        if (mc.field_1705 == null) {
            return;
        }
        class_338 chat = mc.field_1705.method_1743();
        chat.method_1812(component);
    }

    public static void addChatMessage(String message) {
        addChatMessage(true, message);
    }

    public static void addChatMessage(String... message) {
        StringBuilder sb = new StringBuilder();
        for (String s : message) {
            sb.append(s);
        }
        addChatMessage(true, sb.toString());
    }



    public static void addChatMessage(boolean prefix, String... message) {
        StringBuilder sb = new StringBuilder();
        for (String s : message) {
            sb.append(s);
        }
        component(class_2561.method_30163((prefix ? PREFIX : "") + sb));
    }
}
