package today.starain.utils.client;

import today.starain.utils.wrapper.Wrapper;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2596;

public class NetworkUtils implements Wrapper {
    public static Set<class_2596<?>> passthroughsPackets = new HashSet<>();


    public static void sendPacketNoEvent(class_2596<?> packet) {
        passthroughsPackets.add(packet);
        mc.method_1562().method_2883(packet);
    }
}
