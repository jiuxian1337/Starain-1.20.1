package today.starain.utils.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import today.starain.utils.math.MathConst;
import today.starain.utils.wrapper.Wrapper;

public class RotationUtils implements Wrapper {


    public static Rotation calculate(final class_243 from, final class_243 to) {
        final class_243 diff = to.method_1020(from);
        final double distance = Math.hypot(diff.field_1352, diff.field_1350);
        final float yaw = (float) (class_3532.method_15349(diff.field_1350, diff.field_1352) * MathConst.TO_DEGREES) - 90.0F;
        final float pitch = (float) (-(class_3532.method_15349(diff.field_1351, distance) * MathConst.TO_DEGREES));
        return new Rotation(yaw, pitch);
    }

    public static Rotation calculate(final class_1297 entity) {
        return calculate(entity.method_19538().method_1031(0, Math.max(0, Math.min(mc.field_1724.method_23318() - entity.method_23318() +
                mc.field_1724.method_5751(), (entity.method_5829().field_1325 - entity.method_5829().field_1322) * 0.9)), 0));
    }

    public static Rotation calculate(final class_1297 entity, final boolean adaptive, final double range) {
        Rotation normalRotations = RotationUtils.calculate(entity);

        class_239 result = RayCastUtil.rayCast(normalRotations, range, 0.0f);

        if (!adaptive || (result != null && result.method_17783() == class_239.class_240.field_1331)) {
            return normalRotations;
        }

        class_238 bb = entity.method_5829();
        double minX = bb.field_1323;
        double maxX = bb.field_1320;
        double minY = bb.field_1322;
        double maxY = bb.field_1325;
        double minZ = bb.field_1321;
        double maxZ = bb.field_1324;

        class_243 basePos = entity.method_19538();

        for (double yPercent = 1; yPercent >= 0; yPercent -= 0.25 + Math.random() * 0.1) {
            for (double xPercent = 1; xPercent >= -0.5; xPercent -= 0.5) {
                for (double zPercent = 1; zPercent >= -0.5; zPercent -= 0.5) {

                    double offsetX = (maxX - minX) * xPercent;
                    double offsetY = (maxY - minY) * yPercent;
                    double offsetZ = (maxZ - minZ) * zPercent;

                    class_243 targetPoint = basePos.method_1031(offsetX, offsetY, offsetZ);

                    Rotation adaptiveRotations = RotationUtils.calculate(targetPoint);

                    class_239 rayCastResult = RayCastUtil.rayCast(adaptiveRotations, range, 0.0f);

                    if (rayCastResult != null && rayCastResult.method_17783() == class_239.class_240.field_1331) {
                        return adaptiveRotations;
                    }
                }
            }
        }

        return normalRotations;
    }


    public static Rotation calculate(final class_2338 to) {
        return calculate(mc.field_1724.method_33571(), new class_243(to.method_10263(), to.method_10264(), to.method_10260()).method_1031(0.5, 0.5, 0.5));
    }

    public static Rotation calculate(final class_243 to) {
        return calculate(mc.field_1724.method_33571(), to);
    }

    public static Rotation calculate(final class_243 position, final class_2350 enumFacing) {
        double x = position.field_1352 + 0.5D;
        double y = position.field_1351 + 0.5D;
        double z = position.field_1350 + 0.5D;

        x += (double) enumFacing.method_10163().method_10263() * 0.5D;
        y += (double) enumFacing.method_10163().method_10264() * 0.5D;
        z += (double) enumFacing.method_10163().method_10260() * 0.5D;
        return calculate(new class_243(x, y, z));
    }


    public static Rotation calculate(final class_2338 position, final class_2350 enumFacing) {
        double x = position.method_10263() + 0.5D;
        double y = position.method_10264() + 0.5D;
        double z = position.method_10260() + 0.5D;

        x += (double) enumFacing.method_10163().method_10263() * 0.5D;
        y += (double) enumFacing.method_10163().method_10264() * 0.5D;
        z += (double) enumFacing.method_10163().method_10260() * 0.5D;
        return calculate(new class_243(x, y, z));
    }

    public static Rotation applySensitivityPatch(final Rotation rotation) {
        if (mc.field_1724 == null) {
            return rotation;
        }

        float prevYaw = mc.field_1724.field_5982;
        float prevPitch = mc.field_1724.field_6004;
        final Rotation previousRotation = new Rotation(prevYaw, prevPitch);
        final float mouseSensitivity = (float) (mc.field_1690.method_42495().method_41753() * (1 + Math.random() / 10000000) * 0.6F + 0.2F);
        final double multiplier = mouseSensitivity * mouseSensitivity * mouseSensitivity * 8.0F * 0.15D;
        final float yaw = previousRotation.getYaw() + (float) (Math.round((rotation.getYaw() - previousRotation.getYaw()) / multiplier) * multiplier);
        final float pitch = previousRotation.getPitch() + (float) (Math.round((rotation.getPitch() - previousRotation.getPitch()) / multiplier) * multiplier);
        return new Rotation(yaw, class_3532.method_15363(pitch, -90, 90));
    }

    public static Rotation applySensitivityPatch(final Rotation rotation, final Rotation previousRotation) {
        final float mouseSensitivity = (float) (mc.field_1690.method_42495().method_41753() * (1 + Math.random() / 10000000) * 0.6F + 0.2F);
        final double multiplier = mouseSensitivity * mouseSensitivity * mouseSensitivity * 8.0F * 0.15D;
        final float yaw = previousRotation.getYaw() + (float) (Math.round((rotation.getYaw() - previousRotation.getYaw()) / multiplier) * multiplier);
        final float pitch = previousRotation.getPitch() + (float) (Math.round((rotation.getPitch() - previousRotation.getPitch()) / multiplier) * multiplier);
        return new Rotation(yaw, class_3532.method_15363(pitch, -90, 90));
    }

    public static Rotation relateToPlayerRotation(final Rotation rotation) {
        float prevYaw = mc.field_1724.field_5982;
        float prevPitch = mc.field_1724.field_6004;
        final Rotation previousRotation = new Rotation(prevYaw, prevPitch);
        final float yaw = previousRotation.getYaw() + class_3532.method_15392(rotation.getYaw() - previousRotation.getYaw());
        final float pitch = class_3532.method_15340(rotation.getPitch(), -90, 90);
        return new Rotation(yaw, pitch);
    }

    public static Rotation resetRotation(final Rotation rotation) {
        if (rotation == null) {
            return null;
        }

        final float yaw = rotation.getYaw() + class_3532.method_15392(mc.field_1724.method_36454() - rotation.getYaw());
        final float pitch = mc.field_1724.method_36455();
        return new Rotation(yaw, pitch);
    }

    public static Rotation move(final Rotation targetRotation, final double speed) {
        return move(RotationManager.lastRotations, targetRotation, speed);
    }

    public static Rotation move(final Rotation lastRotation, final Rotation targetRotation, double speed) {
        if (speed != 0) {

            double deltaYaw = class_3532.method_15392(targetRotation.getYaw() - lastRotation.getYaw());
            final double deltaPitch = (targetRotation.getPitch() - lastRotation.getPitch());

            final double distance = Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
            final double distributionYaw = Math.abs(deltaYaw / distance);
            final double distributionPitch = Math.abs(deltaPitch / distance);

            final double maxYaw = speed * distributionYaw;
            final double maxPitch = speed * distributionPitch;

            final float moveYaw = (float) Math.max(Math.min(deltaYaw, maxYaw), -maxYaw);
            final float movePitch = (float) Math.max(Math.min(deltaPitch, maxPitch), -maxPitch);

            return new Rotation(moveYaw, movePitch);
        }

        return new Rotation(0, 0);
    }

    public static Rotation smooth(final Rotation targetRotation, final double speed) {
        return smooth(RotationManager.lastRotations, targetRotation, speed);
    }

    public static Rotation smooth(final Rotation lastRotation, final Rotation targetRotation, final double speed) {
        float yaw = targetRotation.getYaw();
        float pitch = targetRotation.getPitch();
        final float lastYaw = lastRotation.getYaw();
        final float lastPitch = lastRotation.getPitch();

        if (speed != 0) {
            Rotation move = move(targetRotation, speed);

            yaw = lastYaw + move.getYaw();
            pitch = lastPitch + move.getPitch();

            for (int i = 1; i <= (int) (class_310.method_1551().method_47599() / 20f + Math.random() * 10); ++i) {

                if (Math.abs(move.getYaw()) + Math.abs(move.getPitch()) > 0.0001) {
                    yaw += (Math.random() - 0.5) / 1000;
                    pitch -= Math.random() / 200;
                }

                /*
                 * Fixing GCD
                 */
                final Rotation rotations = new Rotation(yaw, pitch);
                final Rotation fixedRotations = applySensitivityPatch(rotations);

                /*
                 * Setting rotations
                 */
                yaw = fixedRotations.getYaw();
                pitch = Math.max(-90, Math.min(90, fixedRotations.getPitch()));
            }
        }

        return new Rotation(yaw, pitch);
    }

    public static double getDistance(final class_1297 entity) {
        class_243 eyes = mc.field_1724.method_33571();
        class_238 aabb = entity.method_5829();

        double x = class_3532.method_15350(eyes.field_1352, aabb.field_1323, aabb.field_1320);
        double y = class_3532.method_15350(eyes.field_1351, aabb.field_1322, aabb.field_1325);
        double z = class_3532.method_15350(eyes.field_1350, aabb.field_1321, aabb.field_1324);

        return Math.sqrt(eyes.method_1028(x, y, z));
    }

    public static double getDistance(class_1657 player, final class_1297 entity) {
        class_243 eyes = player.method_33571();
        class_238 aabb = entity.method_5829();

        double x = class_3532.method_15350(eyes.field_1352, aabb.field_1323, aabb.field_1320);
        double y = class_3532.method_15350(eyes.field_1351, aabb.field_1322, aabb.field_1325);
        double z = class_3532.method_15350(eyes.field_1350, aabb.field_1321, aabb.field_1324);

        return Math.sqrt(eyes.method_1028(x, y, z));
    }


}
