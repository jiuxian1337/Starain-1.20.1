package today.starain.utils.rotation;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.world.phys.*;
import today.starain.utils.wrapper.Wrapper;

import java.util.List;
import java.util.Optional;

public final class RayCastUtil implements Wrapper {

    public static class_239 rayCast(final Rotation rotation, final double range) {
        return rayCast(rotation, range, 0);
    }

    public static boolean inView(final class_1297 entity) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || entity == null) return false;

        double renderDistance = mc.field_1690.method_42503().method_41753() * 16.0;

        Rotation rotations = RotationUtils.calculate(entity);

        if (Math.abs(class_3532.method_15392(mc.field_1724.method_36454() - rotations.getYaw())) > mc.field_1690.method_41808().method_41753()) {
            return false;
        }

        double dist = mc.field_1724.method_5739(entity);

        if (dist > 100 || !(entity instanceof class_1657)) {
            class_239 result = RayCastUtil.rayCast(rotations, renderDistance, 0.2f);
            return result != null && result.method_17783() == class_239.class_240.field_1331;
        } else {
            class_238 bb = entity.method_5829();
            double width = bb.method_17939();
            double height = bb.method_17940();
            double depth = bb.method_17941();
            class_243 basePos = entity.method_19538();

            for (double yPercent = 1; yPercent >= -1; yPercent -= 0.5) {
                for (double xPercent = 1; xPercent >= -1; xPercent -= 1.0) {
                    for (double zPercent = 1; zPercent >= -1; zPercent -= 1.0) {

                        class_243 targetPoint = basePos.method_1031(width * xPercent, height * yPercent, depth * zPercent);
                        Rotation subRotations = RotationUtils.calculate(targetPoint);

                        class_239 result = RayCastUtil.rayCast(subRotations, renderDistance, 0.2f);
                        if (result != null && result.method_17783() == class_239.class_240.field_1331) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public static class_239 rayCast(final Rotation rotation, final double range, final float expand) {
        return rayCast(rotation, range, expand, mc.field_1724);
    }

    public static class_239 rayCast(final Rotation rotation, final double range, final float expand, class_1297 entity) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || entity == null) return null;

        float partialTicks = mc.method_1488();

        class_243 eyePos = entity.method_5836(partialTicks);
        class_243 lookVec = class_243.method_1030(rotation.getPitch(), rotation.getYaw());
        class_243 endVec = eyePos.method_1019(lookVec.method_1021(range));

        class_239 objectMouseOver = mc.field_1687.method_17742(new class_3959(
                eyePos,
                endVec,
                class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348,
                entity
        ));

        double distToBlock = range;
        if (objectMouseOver.method_17783() != class_239.class_240.field_1333) {
            distToBlock = objectMouseOver.method_17784().method_1022(eyePos);
        }

        class_243 entitySearchEndVec = eyePos.method_1019(lookVec.method_1021(range));

        class_1297 pointedEntity = null;
        class_243 hitVec = null;
        double currentDist = distToBlock;

        class_238 searchBox = entity.method_5829().method_18804(lookVec.method_1021(range)).method_1014(1.0D);

        List<class_1297> list = mc.field_1687.method_8333(entity, searchBox, e -> !e.method_7325() && e.method_5863());

        for (class_1297 candidate : list) {
            float collisionSize = candidate.method_5871() + expand;
            class_238 entityBox = candidate.method_5829().method_1014(collisionSize);

            Optional<class_243> intercept = entityBox.method_992(eyePos, entitySearchEndVec);

            if (entityBox.method_1006(eyePos)) {
                if (currentDist >= 0.0D) {
                    pointedEntity = candidate;
                    hitVec = intercept.orElse(eyePos);
                    currentDist = 0.0D;
                }
            } else if (intercept.isPresent()) {
                class_243 interceptVec = intercept.get();
                double d3 = eyePos.method_1022(interceptVec);

                if (d3 < currentDist || currentDist == 0.0D) {
                    if (candidate.method_5668() == entity.method_5668() ) {
                        if (currentDist == 0.0D) {
                            pointedEntity = candidate;
                            hitVec = interceptVec;
                        }
                    } else {
                        pointedEntity = candidate;
                        hitVec = interceptVec;
                        currentDist = d3;
                    }
                }
            }
        }

        if (pointedEntity != null && (currentDist < distToBlock || objectMouseOver.method_17783() == class_239.class_240.field_1333)) {
            return new class_3966(pointedEntity, hitVec);
        }

        return objectMouseOver;
    }

    public static boolean overBlock(final Rotation rotation, final class_2350 enumFacing, final class_2338 pos, final boolean strict) {
        class_310 mc = class_310.method_1551();

        if (mc.field_1724 == null || mc.field_1687 == null) return false;

        class_243 lookVec = class_243.method_1030(rotation.getPitch(), rotation.getYaw());

        class_243 eyePos = mc.field_1724.method_5836(1.0F);
        double reach = 4.5D;
        class_243 endVec = eyePos.method_1019(lookVec.method_1021(reach));

        class_3965 result = mc.field_1687.method_17742(new class_3959(
                eyePos,
                endVec,
                class_3959.class_3960.field_17559,
                class_3959.class_242.field_1348,
                mc.field_1724
        ));

        if (result.method_17783() == class_239.class_240.field_1333) return false;

        return result.method_17777().equals(pos)
                && (!strict || result.method_17780() == enumFacing);
    }

    public static boolean overBlock(final class_2350 enumFacing, final class_2338 pos, final boolean strict) {
        return overBlock(RotationManager.getRotation(), class_2350.field_11036, pos, false);
    }

    public static Boolean overBlock(final Rotation rotation, final class_2338 pos) {
        return overBlock(rotation, class_2350.field_11036, pos, false);
    }

    public static Boolean overBlock(final Rotation rotation, final class_2338 pos, final class_2350 enumFacing) {
        return overBlock(rotation, enumFacing, pos, true);
    }


}
