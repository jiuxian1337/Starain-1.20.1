package today.starain.utils.render;


import org.joml.Quaternionf;
import org.joml.Vector3f;
import today.starain.utils.vector.Vector2f;

import java.lang.reflect.Method;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class ProjectionUtils {
    private static final class_310 mc = class_310.method_1551();

    public static Vector2f project(double x, double y, double z, float renderPartialTicks) {
        class_243 camera_pos = mc.method_1561().field_4686.method_19326();
        Quaternionf cameraRotation = new Quaternionf(mc.method_1561().method_24197());
        cameraRotation.conjugate();
        Vector3f result3f = new Vector3f((float) (camera_pos.field_1352 - x), (float) (camera_pos.field_1351 - y), (float) (camera_pos.field_1350 - z));
        result3f.rotate(cameraRotation);
        if (mc.field_1690.method_42448().method_41753() && mc.method_1560() instanceof class_1657 playerentity) {
            calculateViewBobbing(playerentity, result3f, renderPartialTicks);
        }

        double fov = mc.field_1773.method_3196(mc.method_1561().field_4686, renderPartialTicks, true);

        return calculateScreenPosition(result3f, fov);
    }

    private static void calculateViewBobbing(class_1657 playerentity, Vector3f result3f, float renderPartialTicks) {
        float walked = playerentity.field_5973;
        float f = walked - playerentity.field_6039;
        float f1 = -(walked + f * renderPartialTicks);
        float f2 = class_3532.method_16439(renderPartialTicks, playerentity.field_7505, playerentity.field_7483);
        Quaternionf quaternion = new Quaternionf().rotationX(Math.abs(class_3532.method_15362(f1 * (float) Math.PI - 0.2F) * f2) * 5.0F * (float) (Math.PI / 180.0));
        quaternion.conjugate();
        result3f.rotate(quaternion);
        Quaternionf quaternion1 = new Quaternionf().rotationZ(class_3532.method_15374(f1 * (float) Math.PI) * f2 * 3.0F * (float) (Math.PI / 180.0));
        quaternion1.conjugate();
        result3f.rotate(quaternion1);
        Vector3f bobTranslation = new Vector3f(class_3532.method_15374(f1 * (float) Math.PI) * f2 * 0.5F, -Math.abs(class_3532.method_15362(f1 * (float) Math.PI) * f2), 0.0F);
        bobTranslation.y = -bobTranslation.y;
        result3f.add(bobTranslation);
    }

    private static Vector2f calculateScreenPosition(Vector3f result3f, double fov) {
        float halfHeight = (float) mc.method_22683().method_4502() / 2.0F;
        float scaleFactor = halfHeight / (result3f.z() * (float) Math.tan(Math.toRadians(fov / 2.0)));
        return result3f.z() < 0.0F
                ? new Vector2f(
                -result3f.x() * scaleFactor + (float) mc.method_22683().method_4486() / 2.0F,
                (float) mc.method_22683().method_4502() / 2.0F - result3f.y() * scaleFactor
        )
                : new Vector2f(Float.MAX_VALUE, Float.MAX_VALUE);
    }
}
