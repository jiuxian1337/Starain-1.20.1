package today.starain.utils.wrapper;

import java.io.File;
import net.minecraft.class_310;

public interface Wrapper {
    class_310 mc = class_310.method_1551();
}
